

public interface Comparer {
	public int compare(Object left, Object right);
}

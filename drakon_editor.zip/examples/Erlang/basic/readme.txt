A basic demo for DRAKON-Erlang.

How to run:
1. Start Erlang shell.
	erl
2. Compile
	c(basic).
3. Run
	basic:run().
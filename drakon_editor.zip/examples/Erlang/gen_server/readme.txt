A gen_server demo for DRAKON-Erlang.

How to run:
1. Start Erlang shell.
	erl
2. Compile
	c(musician).
3. Run
	musician:run().